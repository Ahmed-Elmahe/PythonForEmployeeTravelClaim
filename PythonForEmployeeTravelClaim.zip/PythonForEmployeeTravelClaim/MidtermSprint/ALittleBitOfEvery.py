# Description: This program calculates equipment amortization
# Author: Adewale Gbadamosi
# Date: February 16, 2024

# importing library
from datetime import datetime, timedelta

class Equipment:
    def __init__(self, cost, purchase_date):
        self.cost = cost
        self.purchase_date = purchase_date
        self.salvage_value = 0.10 * cost
        self.useful_life_months = 15 * 12

    def maintenance_dates(self):
        cleaning = self.purchase_date + timedelta(days=10)
        tube_fluid = self.purchase_date + timedelta(weeks=3)
        major_inspection = self.purchase_date + timedelta(days=180)
        return cleaning, tube_fluid, major_inspection

    def monthly_amortization(self):
        return (self.cost - self.salvage_value) / self.useful_life_months

    def display_schedule(self):
        cleaning, tube_fluid, major_inspection = self.maintenance_dates()
        amortization = self.monthly_amortization()
        print(f" \n                   XYZ Equipment")
        print(f"               131 Elizabeth Avenue")
        print(f"               --------------------")
        print(f" \nMaintenance Schedule")
        print(f"\n Basic Cleaning (10 days):        {cleaning.strftime('%B %d, %Y')}")
        print(f" Tube and Fluid Checks (3 weeks): {tube_fluid.strftime('%B %d, %Y')}")
        print(f" Major Inspection (6 months):     {major_inspection.strftime('%B %d, %Y')}")
        print(" \nMonthly Amortization")
        print(f"\n Cost of Equipment:                ${self.cost:,.2f}")
        print(f" Salvage Value:                    ${self.salvage_value:,.2f}")
        print(f"\n Monthly Amortization:             ${amortization:,.2f}")
        print(f"\n --------------------------------------------")
        print()

def main():
    while True:
        while True:
            try:
                cost = float(input("Enter the cost of the equipment: "))
                break
            except:
                print("Data Value Error - invalid input")
        while True:
            try:
                purchase_date_str = input("Enter the purchase date (YYYY-MM-DD): ")
                purchase_date = datetime.strptime(purchase_date_str, '%Y-%m-%d')
                break
            except:
                print("Data Value Error - invalid date input")
        equip = Equipment(cost, purchase_date)
        equip.display_schedule()
        while True:
            continue_prompt = input("Do you want to process another amortization (Y / N): ").strip().upper()
            if continue_prompt == "":
                print("Data Entry Error - Continue option cannot be blank.")
            elif continue_prompt not in ("Y", "N"):
                print("Data Entry Error - Continue option must be a Y or N.")
            else:
                break
        if continue_prompt == "N":
            break
    print("\nProgram ended.")

if __name__ == "__main__":
    main()






