# Description: This is the program for generating 12 characters random password
# Author: Adewale Gbadamosi
# Date: February 18, 2024

# import the secrets module, which provides functions for generating random numbers
# import the string module, which provides a collection of constants representing ASCII character sets.
import secrets
import string
import calendar

class PasswordGenerator:
    def __init__(self, length=12):
        self.length = length
        self.characters = string.ascii_letters + string.digits + string.punctuation

    def generate(self):
        return ''.join(secrets.choice(self.characters) for _ in range(self.length))

def display_calendar():
    while True:
        try:
            month = int(input("Enter the month: "))
            year = int(input("Enter the year: "))
            print(calendar.month(year, month))
            break
        except:
            print("Invalid month or year. Please enter valid numbers.")

def main():
    while True:
        print()
        display_calendar()
        generator = PasswordGenerator()
        password = generator.generate()
        print()
        print("|---------------------------------|")
        print(f"|Generated Password: {password:<16}|")
        print("|---------------------------------|")
        print()
        while True:
            continue_prompt = input("Do you want to generate another password (Y / N): ").strip().upper()
            if continue_prompt == "":
                print("Data Entry Error - Continue option cannot be blank.")
            elif continue_prompt not in ("Y", "N"):
                print("Data Entry Error - Continue option must be a Y or N.")
            else:
                break
        if continue_prompt == "N":
            break
    print("\nProgram ended.")

if __name__ == "__main__":
    main()
