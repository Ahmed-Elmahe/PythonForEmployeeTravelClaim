# Description: This program calculate the employee travel claim
# Author: Adewale Gbadamosi
# Date: February 16, 2024

# importing library
import datetime, random

# Constants
PER_DIEM_DAILY_RATE = 85.00
PER_KILOMETER_RATE = 0.17
RENTAL_DAILY_RATE = 65.00
MORE_THAT_3DAYS_BONUS = 100
EXTRA_KILOMETER_RATE = 0.04
EXECUTIVE_BONUS_RATE = 45.00
DEC15_22_BONUS = 50.00
HST_RATE = 0.15

ALLOWED_CHAR = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz'.,-")

class Employee:
    def __init__(self, emp_num, first_name, last_name):
        self.emp_num = emp_num
        self.first_name = first_name
        self.last_name = last_name

class TravelClaim:
    def __init__(self, employee, trip_location, start_date, end_date, vehicle_used, kilo_travelled, claim_type):
        self.employee = employee
        self.trip_location = trip_location
        self.start_date = start_date
        self.end_date = end_date
        self.vehicle_used = vehicle_used
        self.kilo_travelled = kilo_travelled
        self.claim_type = claim_type
        self.days = (end_date - start_date).days

    def calculate(self):
        per_diem = self.days * PER_DIEM_DAILY_RATE
        if self.vehicle_used == "O":
            mileage_amt = self.kilo_travelled * PER_KILOMETER_RATE
            vehicle_msg = "Mileage Amount"
            vehicle_usage = "Owned"
        else:
            mileage_amt = self.days * RENTAL_DAILY_RATE
            vehicle_msg = "Rental Amount"
            vehicle_usage = "Rented"

        bonus = 0
        if self.days > 3:
            bonus += MORE_THAT_3DAYS_BONUS
        if self.vehicle_used == "O" and self.kilo_travelled > 1000:
            bonus += self.kilo_travelled * EXTRA_KILOMETER_RATE
        if self.claim_type == "E":
            bonus += self.days * EXECUTIVE_BONUS_RATE
            claim_type_disp = "Executive"
        else:
            claim_type_disp = "Standard"
        if self.start_date.month == 12 and 15 <= self.start_date.day <= 22:
            bonus += self.days * DEC15_22_BONUS

        claim_amt = per_diem + mileage_amt + bonus
        tax = claim_amt * HST_RATE
        total = claim_amt + tax

        return {
            "per_diem": per_diem,
            "mileage_amt": mileage_amt,
            "vehicle_msg": vehicle_msg,
            "vehicle_usage": vehicle_usage,
            "bonus": bonus,
            "claim_amt": claim_amt,
            "tax": tax,
            "total": total,
            "claim_type_disp": claim_type_disp
        }

def get_valid_input(prompt, validate_func, error_msg):
    while True:
        value = input(prompt).strip()
        if validate_func(value):
            return value
        print(error_msg)

def get_employee():
    emp_num = get_valid_input(
        "Enter the employee number:         ",
        lambda x: x.isdigit() and len(x) == 5,
        "Data Entry Error - employee number must be 5 digits."
    )
    first_name = get_valid_input(
        "Enter the employee first name:     ",
        lambda x: x != "" and set(x).issubset(ALLOWED_CHAR),
        "Data Entry Error - employee first name contains invalid characters or is blank."
    ).title()
    last_name = get_valid_input(
        "Enter the employee last name:      ",
        lambda x: x != "" and set(x).issubset(ALLOWED_CHAR),
        "Data Entry Error - employee last name contains invalid characters or is blank."
    ).title()
    return Employee(emp_num, first_name, last_name)

def get_trip_info():
    trip_location = get_valid_input(
        "Enter the trip location:           ",
        lambda x: x != "" and set(x).issubset(ALLOWED_CHAR),
        "Data Entry Error - trip location contains invalid characters or is blank."
    ).title()
    while True:
        try:
            start_date = datetime.datetime.strptime(
                input("Enter the start date of the trip (YYYY-MM-DD): ").strip(), "%Y-%m-%d"
            )
            break
        except:
            print("Data Entry Error - start date is not in a valid format.")
    while True:
        try:
            end_date = datetime.datetime.strptime(
                input("Enter the end date of the trip (YYYY-MM-DD) - must be within 7 days of start day: ").strip(), "%Y-%m-%d"
            )
            if (end_date - start_date).days > 7:
                print("Data Entry Error - end date must be within 7 days of start date.")
            else:
                break
        except:
            print("Data Entry Error - end date is not in a valid format.")
    return trip_location, start_date, end_date

def get_vehicle_info():
    vehicle_used = get_valid_input(
        "Enter the vehicle used ('O' for owned and 'R' for rented):    ",
        lambda x: x.upper() in ("O", "R") and len(x) == 1,
        "Data Entry Error - must be one letter ('O' for owned and 'R' for rented.)"
    ).upper()
    kilo_travelled = 0
    if vehicle_used == "O":
        while True:
            try:
                kilo_travelled = int(input("Enter the kilometer travelled:     "))
                if kilo_travelled > 2000:
                    print("Data Entry Error - Kilometer travelled cannot exceed 2,000km")
                else:
                    break
            except:
                print("Data Entry Error - not a valid number.")
    return vehicle_used, kilo_travelled

def get_claim_type():
    return get_valid_input(
        "Enter the claim type ('E' for Executive and 'S' for Standard: ",
        lambda x: x.upper() in ("E", "S") and len(x) == 1,
        "Data Entry Error - must be one letter ('E' for Executive or 'S' for Standard.)"
    ).upper()

def display_claim(claim: TravelClaim, calc: dict):
    emp = claim.employee
    print(f"\n ------------------------------------------")
    print(f"          NL Chocolate Company")
    print(f"         Employee Travel Claims")
    print(f" ------------------------------------------\n")
    print(f" Employee: {emp.emp_num:>5s}")
    print(f"           {emp.first_name[0]}. {emp.last_name:<24s}\n")
    print(f" Trip Location:      {claim.trip_location}")
    print(f" Start Date:         {claim.start_date.strftime('%Y-%m-%d')}")
    print(f" End Date:           {claim.end_date.strftime('%Y-%m-%d')}")
    print(f" Number of Days:    {claim.days:>2d} days\n")
    print(f" Claim Type:         {calc['claim_type_disp']:<10s}")
    print(f" Vehicle Used:       {calc['vehicle_usage']}")
    if claim.vehicle_used == "O":
        print(f" Kilometer Travel:   {claim.kilo_travelled:>4d} km")
    print(f"")
    print(f" Per Diem Amount:                 ${calc['per_diem']:>9,.2f}")
    print(f" {calc['vehicle_msg']:<14s}:                  ${calc['mileage_amt']:>9,.2f}")
    print(f" Bonus:                           ${calc['bonus']:>9,.2f}")
    print(f"                                  ---------")
    print(f" Claim Amount:                    ${calc['claim_amt']:>9,.2f}")
    print(f" Tax (HST):                       ${calc['tax']:>9,.2f}")
    print(f"                                  ---------")
    print(f" Total Claim Amount:              ${calc['total']:>9,.2f}")
    print(f" ------------------------------------------\n")
    print(f"       Issued: {datetime.date.today()}")
    print(f"       Claim Reference: {emp.first_name[0]}{emp.last_name[0]}-{emp.emp_num[3:]}-{random.randint(0,9999)}\n")
    print(f" ------------------------------------------\n")

def main():
    while True:
        employee = get_employee()
        trip_location, start_date, end_date = get_trip_info()
        vehicle_used, kilo_travelled = get_vehicle_info()
        claim_type = get_claim_type()
        claim = TravelClaim(employee, trip_location, start_date, end_date, vehicle_used, kilo_travelled, claim_type)
        calc = claim.calculate()
        display_claim(claim, calc)
        cont = get_valid_input(
            "Do you want to process another travel claim (Y / N): ",
            lambda x: x.upper() in ("Y", "N") and len(x) == 1,
            "Data Entry Error - Continue option must be a Y or N."
        ).upper()
        if cont == "N":
            break
    print("\nProgram ended.")

if __name__ == "__main__":
    main()
