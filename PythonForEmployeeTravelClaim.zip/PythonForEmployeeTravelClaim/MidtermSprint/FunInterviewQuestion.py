# Description: FizzBuzz game using class and function
# Author: Adewale Gbadamosi
# Date: February 16, 2024

class FizzBuzzGame:
    def __init__(self, start=1, end=100):
        self.start = start
        self.end = end

    def play(self):
        for num in range(self.start, self.end + 1):
            output = ""
            if num % 5 == 0:
                output += "Fizz"
            if num % 8 == 0:
                output += "Buzz"
            print(output if output else num)

def main():
    while True:
        game = FizzBuzzGame()
        game.play()
        while True:
            continue_prompt = input("Do you want to play another game (Y / N): ").strip().upper()
            if continue_prompt == "":
                print("Data Entry Error - Continue option cannot be blank.")
            elif continue_prompt not in ("Y", "N"):
                print("Data Entry Error - Continue option must be a Y or N.")
            else:
                break
        if continue_prompt == "N":
            break
    print("\nProgram ended.")

if __name__ == "__main__":
    main()
