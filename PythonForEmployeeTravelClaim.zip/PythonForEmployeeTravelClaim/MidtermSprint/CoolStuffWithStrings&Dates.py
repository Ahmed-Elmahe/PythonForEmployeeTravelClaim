# Description: This program generate employee ID, Username and Password
# Author: Adewale Gbadamosi
# Date: February 17, 2024

from datetime import datetime, timedelta

class Employee:
    allowed_char = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz'.,-")

    def __init__(self):
        self.first_name = ""
        self.last_name = ""
        self.start_date = None
        self.birth_date = None
        self.phone_num = ""
        self.current_date = datetime.now()

    def input_name(self, prompt):
        while True:
            name = input(prompt).strip().title()
            if not name:
                print("Data Entry Error - name cannot be blank.")
            elif not set(name).issubset(self.allowed_char):
                print("Data Entry Error - name contains invalid characters.")
            else:
                return name

    def input_date(self, prompt):
        while True:
            try:
                date_str = input(prompt).strip()
                date = datetime.strptime(date_str, "%Y-%m-%d")
                return date
            except:
                print("Data Entry Error - date is not in a valid format.")

    def input_phone(self):
        while True:
            phone = input("Enter phone number (9999999999):      ").strip()
            if not phone:
                print("Data Entry Error - Phone number cannot be blank")
            elif not phone.isdigit():
                print("Data Entry Error - phone number must be digit number")
            elif len(phone) != 10:
                print("Data Entry Error - phone number must 10 digit number")
            else:
                return phone

    def gather_info(self):
        self.first_name = self.input_name("Enter the employee first name:        ")
        self.last_name = self.input_name("Enter the employee last name:         ")
        self.start_date = self.input_date("Enter the start date (YYYY-MM-DD):    ")
        self.birth_date = self.input_date("Enter the birthdate (YYYY-MM-DD):     ")
        self.phone_num = self.input_phone()

    def generate_employee_id(self):
        return f"{self.first_name[0]}{self.last_name[0]}{self.start_date.strftime('%Y%m%d')}"

    def generate_username(self):
        return f"{self.first_name.lower()}.{self.last_name.lower()}{self.birth_date.strftime('%y')}"

    def generate_password(self):
        return f"{self.last_name[::-1]}{self.birth_date.strftime('%Y')}"

    def years_and_days_worked(self):
        days = (self.current_date - self.start_date).days
        return days // 365, days % 365

    def years_until_retirement(self, retirement_age=65):
        age = self.current_date.year - self.birth_date.year
        if (self.current_date.month, self.current_date.day) < (self.birth_date.month, self.birth_date.day):
            age -= 1
        return retirement_age - age

    def days_until_next_birthday(self):
        next_birthday = self.birth_date.replace(year=self.current_date.year)
        if next_birthday < self.current_date:
            next_birthday = next_birthday.replace(year=self.current_date.year + 1)
        return (next_birthday - self.current_date).days

    def display_profile(self):
        emp_id = self.generate_employee_id()
        username = self.generate_username()
        password = self.generate_password()
        years, days = self.years_and_days_worked()
        years_to_retire = self.years_until_retirement()
        days_to_birthday = self.days_until_next_birthday()
        print(f"\n------------------------------------------------")
        print(f"            AJ Service Limited")
        print(f"   121 Elizabeth Avenue, St. John's NL A1B3G4")
        print(f"------------------------------------------------")
        print("\nEmployee Profile:")
        print(f"-----------------")
        print(f" First Name:   {self.first_name}")
        print(f" Last Name:    {self.last_name}")
        print(f" Phone Number: {self.phone_num}")
        print(f" Start Date:   {self.start_date.strftime('%B %d, %Y')}")
        print(f" Birthdate:    {self.birth_date.strftime('%B %d, %Y')}")
        print("\nEmployee Details:")
        print(f"-----------------")
        print(f" Employee ID:  {emp_id}")
        print(f" Username:     {username}")
        print(f" Password:     {password}")
        print(f"\n+++++++++++++++++++++++++++++++++++++++++++++++++")
        print(f"+  Years and Days Worked:    {years} years, {days} days  +")
        print(f"+  Years Until Retirement:   {years_to_retire} years           +")
        print(f"+  Days Until Next Birthday: {days_to_birthday} days           +")
        print(f"+++++++++++++++++++++++++++++++++++++++++++++++++")
        print()

def main():
    while True:
        emp = Employee()
        emp.gather_info()
        emp.display_profile()
        while True:
            continue_prompt = input("Do you want to process another employee (Y / N): ").strip().upper()
            if continue_prompt == "":
                print("Data Entry Error - Continue option cannot be blank.")
            elif continue_prompt not in ("Y", "N"):
                print("Data Entry Error - Continue option must be a Y or N.")
            else:
                break
        if continue_prompt == "N":
            break
    print("\nProgram ended.")

if __name__ == "__main__":
    main()
