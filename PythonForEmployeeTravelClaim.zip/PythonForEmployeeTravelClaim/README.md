# Midtream Python

This project is a Python-based solution for employee travel claims.

## Features

- Submit and manage travel claims
- User-friendly interface
- Automated calculations
